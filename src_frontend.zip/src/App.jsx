import React from 'react'
import HostelHomepage from './components/HostelHomePage'
import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
import QuickStats from './components/QuickStats'
import FeaturedHostels from './components/FeaturedHostels'
import WhyChooseUs from './components/WhyChooseUs'
import Footer from './components/Footer'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import StudentSignup from './pages/StudentSignup'
import LoginPage from './pages/LoginPage'
import OwnerSignup from './pages/OwnerSignup'

const App = () => {

  const router = createBrowserRouter([
    {
      path: '/',
      element: <>
        <Navbar />
        <HeroSection />
        <QuickStats />
        <FeaturedHostels />
        <WhyChooseUs />
        <Footer />
      </>
    },
    {
      path: '/studentsignup',
      element: <><StudentSignup /></>
    },
    {
      path: '/login',
      element: <><LoginPage /></>
    },
    {
      path: '/ownersignup',
      element: <><OwnerSignup /></>
    }
  ]);

  return (
    <div>
      {/* <HostelHomepage /> */}
      {/* <Navbar />
      <HeroSection />
      <QuickStats />
      <FeaturedHostels />
      <WhyChooseUs />
      <Footer /> */}
      <RouterProvider router={router} />
    </div>
  )
}

export default App